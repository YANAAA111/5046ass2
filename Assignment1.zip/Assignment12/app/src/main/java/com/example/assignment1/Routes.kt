package com.example.assignment1

enum class Routes(val value: String) {
    Home("Home"),
    Profile("Profile"),
    About("About")
}
