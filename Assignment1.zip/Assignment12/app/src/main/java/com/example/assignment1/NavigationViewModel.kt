package com.example.assignment1
import androidx.lifecycle.ViewModel
import androidx.compose.runtime.mutableStateOf

class NavigationViewModel: ViewModel() {
    val name = mutableStateOf("")
    fun setName(newName: String) {
        name.value = newName
    }
}

