package com.example.assignment1

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.assignment1.ui.theme.Assignment1Theme

@Composable
fun LoginScreen() {
    // State hoisting for email and password
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Logo 图片
        Image(
            painter = painterResource(id = R.drawable.logo),
            contentDescription = "App Logo", // 提供内容描述以支持无障碍功能
            modifier = Modifier
                .size(100.dp) // 可以根据需要调整大小
                .padding(bottom = 24.dp) // 在图片和下一个元素之间添加一些空间
        )

        // "Smart Parking" 标题
        Text(
            text = "Smart Parking",
            style = MaterialTheme.typography.headlineMedium.copy(fontSize = 30.sp),
            modifier = Modifier.padding(bottom = 24.dp)
        )

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") }
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { /* 处理点击事件 */ },
            // 使用 ButtonDefaults.buttonColors 来定义按钮的颜色
            colors = ButtonDefaults.buttonColors(containerColor = Color.Cyan), // 将按钮背景设置为青色
            modifier = Modifier.padding(15.dp)
        ) {
            Text("Register")
        }

        Button(
            onClick = {
                // Handle login logic here
            }
        ) {
            Text("Log In")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    Assignment1Theme {
        LoginScreen()
    }
}
