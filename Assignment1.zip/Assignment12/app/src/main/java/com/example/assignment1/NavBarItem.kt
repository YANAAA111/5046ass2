package com.example.assignment1

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.ui.graphics.vector.ImageVector

data class NavBarItem(
    val label: String = "",
    val icon: ImageVector = Icons.Filled.Home,
    val route: String = ""
) {
    companion object {
        fun navBarItems(): List<NavBarItem> {
            return listOf(
                NavBarItem(
                    label = "Home",
                    icon = Icons.Filled.Home,
                    route = Routes.Home.value
                ),
                NavBarItem(
                    label = "Profile",
                    icon = Icons.Filled.AccountCircle,
                    route = Routes.Profile.value
                ),
                NavBarItem(
                    label = "About",
                    icon = Icons.Filled.Person,
                    route = Routes.About.value
                )
            )
        }
    }
}
